from .hk_print import HKPrint, HKPrintTheme

print = HKPrint()