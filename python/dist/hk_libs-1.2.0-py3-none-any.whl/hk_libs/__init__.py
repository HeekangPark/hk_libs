from .HKPrint import HKPrint, HKPrintTheme
from .HKDict import HKDict

print = HKPrint()