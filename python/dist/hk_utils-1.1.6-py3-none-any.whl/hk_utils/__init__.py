from .hk_print import HKPrint, HKPrintTheme
from .AttrDict import AttrDict

print = HKPrint()